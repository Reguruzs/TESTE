const config = {
        botName: 'hikiriBOT',
        ownerName: 'k1r1t0&daniel',
        youtube: 'https://youtube.com/channel/UCz0zX7CX5V4RsFKB8lncYRQ',
        instagram: 'https://www.instagram.com/invites/contact/?i=1qvase4upo3tz&utm_content=kw5928w',
}
